import { RestaurantIsOpenDirective } from './restaurant-is-open.directive';

describe('RestaurantIsOpenDirective', () => {
  it('should create an instance', () => {
    const directive = new RestaurantIsOpenDirective();
    expect(directive).toBeTruthy();
  });
});
