import { OpenRestaurantsPipe } from './open-restaurants.pipe';

describe('OpenRestaurantsPipe', () => {
  it('create an instance', () => {
    const pipe = new OpenRestaurantsPipe();
    expect(pipe).toBeTruthy();
  });
});
